<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<HTML><HEAD><TITLE>Natural Resources Consultants, (NRC)</TITLE>
<meta name="robots" content="index,follow" />
<meta name="googlebot" content="index,follow" />
<meta name="revisit-after" content="10 days" />
<meta name="copyright" content="NRC Corp" />
<meta name="classification" content="Marine and inland fisheries" />
<meta name="author" content="NRC Corp, Seattle, WA" />
<meta name="language" content="EN" />
<META name="description" content="Comprehensive consulting services for all aspects of local, national and international marine and inland fisheries and their related resource base.">
<META name="keywords" content="fisheries, fishing, salmon, groundfish, cable interaction, environmental impact, Endangered, management, conservation"> 

<SCRIPT type="text/javascript" src="mainmenu.js"></SCRIPT>
<script type="text/javascript" src="bsn.Crossfader.js"></script>
<script type="text/javascript" src="bsn.Crossfader_text.js"></script>


<LINK REL=STYLESHEET TYPE="text/css" HREF="styles.css">
</HEAD>
<BODY BGCOLOR="#FFFFFF"  BACKGROUND="pics/bg2.png" TOPMARGIN="0" LEFTMARGIN="0" MARGINHEIGHT="0" MARGINWIDTH="0">
<!-- MENU PAGE POINTER -->

<DIV ALIGN=center>
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" style="text-align:left; width:1000px;">
<TR><TD ALIGN=left style="text-align:left; width:232px;">
<img style="border-width: 0px;" src="pics/logo.png" width="231" height="65" /></TD>
<TD VALIGN=top ALIGN=left style="text-align:left; width:400px;">
<img style="border-width: 0px;" src="pics/spacer.gif" width="400" height="1" /><BR>

<!--TOP MENU-->
<A HREF=company.php CLASS=m3h>COMPANY</A> &nbsp;  &nbsp;     
<A HREF=services.php CLASS=m3h>SERVICES</A> &nbsp;  &nbsp;     
<A HREF=clients.php CLASS=m3h>CLIENTS</A> &nbsp;  &nbsp;     
<A HREF=projects.php CLASS=m3h>PROJECTS</A> &nbsp;  &nbsp;     
<A HREF=staff.php CLASS=m3h>STAFF</A><BR>     
<A HREF=news.php CLASS=m3h>NEWS & EVENTS</A> &nbsp;  &nbsp;        
<A HREF=library.php CLASS=m3h>LIBRARY</A> &nbsp;  &nbsp;       
<A HREF=jobs.php CLASS=m3h>JOBS</A> &nbsp;  &nbsp;      
<A HREF=contact.php CLASS=m3h>CONTACT</A> &nbsp;  &nbsp;   
<A HREF=index.php CLASS=m3h>HOME</A>  

</TD>
<TD ALIGN=left style="text-align:left; width:233px;">
<img style="border-width: 0px;" src="pics/global_leader.png" width="233" height="58" />
</TD><TR>
<TR><TD COLSPAN=2 VALIGN=top><img style="border-width: 0px;" src="pics/top_tag.png" width="436" height="30" /></TD><TD CLASS=cream10 VALIGN=bottom ALIGN=center>SERVICES</TD><TR>
</TABLE>



<!--START MAIN BODY-->
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH="964px" style="text-align:left;">
<TR><TD VALIGN=top>

<!--LEFT MENU-->
<TABLE CELLPADDING="0" CELLSPACING="0" WIDTH="280px" BORDER="0" BGCOLOR=#0c3159>
<TR><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40" HEIGHT="12px" BORDER="0" ALT=""></TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="200" HEIGHT="32px" BORDER="0" ALT=""><BR>
<SPAN CLASS=cream10>Services:</SPAN>
<BR><BR>
<A HREF=fisheries.php CLASS=mm>Fishery Management & Policy</A><BR><A HREF=environ.php CLASS=mm>Environmental Impact</A><BR><A HREF=economic.php CLASS=mm>Economic Assessment & Impacts</A><BR><A HREF=witness.php CLASS=mm>Fishery Expert Witness</A><BR><A HREF=investigation.php CLASS=mm>Salmon Investigations</A><BR><A HREF=infrastructure.php CLASS=mm>Infrastructure Development</A><BR><A HREF=gear.php CLASS=mm>Derelict Gear Removal</A><BR><A HREF=cable.php CLASS=mm>Cable-Fisheries Interaction</A><BR>
<A HREF=energy.php CLASS=mm>Energy Management Program</A><BR> 
</TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40" HEIGHT="282px" BORDER="0" ALT="">
</TD><TR>
</TABLE>

</TD><TD VALIGN=top ALIGN=left WIDTH="684px">
<IMG SRC="pics/spacer.gif" WIDTH="600" HEIGHT="12px" BORDER="0" ALT="" /><BR>
<img src="pics/services_cable.jpg" width="684px" height="269px"BORDER="0" ALT="" />
</TD>

</TD></TR>
</TABLE>

<TABLE CELLPADDING="0" BACKGROUND="" CELLSPACING="0" BORDER="0" WIDTH=964>
<TR><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="280" HEIGHT="1px" BORDER="0" ALT="">
</TD><TD VALIGN=top CLASS=bodyblue10 style="text-align:left;">
<IMG SRC="pics/spacer.gif" WIDTH="680" HEIGHT="1px" BORDER="0" ALT=""><BR>
<BR>
<b>Cable-Fisheries Interaction :: Examples of  NRC Projects</b>
<BR>
<UL style="list-style: none; ">
<LI>A Brief Summary of the Major Fisheries Activities Occurring in Southern California
<LI>AAN Cable Desktop Study—Fishery Threats
<LI>Advice on Remediation of a Fiber Optic Cable System Burial Problem
<LI>APCN2 Cable Studies
<LI>Apollo Cable Fisheries Impacts, East Coast
<LI>Apollo Desktop Study—Fishery Threats
<LI>Biological Evaluation and Essential Fish Habitat Assessment for the Advanced Deployable Systems Trawl Threat Study, Useless Bay, Admiralty Inlet, Puget Sound, at Island County, Washington
<LI>Biological Evaluation and Essential Fish Habitat Assessment for the Testing of a Small, Lightweight Cable Burial System in the Useless <LI>Bay Cable Test Area 1, Admiralty Inlet
<LI>Bottom Contact Fishery Threats of Taiwan Distant Water Fleets
<LI>Bottom Contact Fisheries along the GBS Cable Route
<LI>Bottom Contact Fisheries in the Korea Strait
<LI>Bottom Contact Fisheries of Onslow Bay, North Carolina
<LI>Bottom Contact Fisheries off Taiwan
<LI>Bottom Contact Fisheries of the East Coast of Korea
<LI><LI>Bottom Contact Fishing on the Argentine Shelf Section of the 360 Americas Fiber Optic Cable with Special Reference to Scallop Dredging
<LI>Brief Overview of Fisheries of the Denmark Strait
<LI>Burial Assessment Report on Japan-US and China-US Cable Systems in California
<LI>Burial Assessment Planning for Japan-US Cable System in California
<LI>Cable Landing Sites on the West Coast of India
<LI>Cable Repair Market Assessment
<LI>Cable Survivability Studies (Biological Threats)
<LI>Chevron California Cable Landing Development Project
<LI>Commercial and Recreational Fisheries of Central and Southern Puget Sound
<LI>Commercial fisheries off the Oregon and Washington Landings of the 360 Pacific Submarine Fiber Optic Cable Network
<LI>Commercial and Sport Fisheries along a Proposed West Coast Festoon Cable Route
<LI>Manchester Cable Landing Feasibility Study
<LI>Corvis Submarine Cable Business Feasibility Study
<LI><LI>C2C Desktop Study 
<LI>Desktop Study for a Multiple Cable Landing Site at Monterey, California
<LI>Desktop Study for Americas 3 Cable System
<LI>Desktop Study for the Southeast Asian Cable Network
<LI>The Direct Economic Impact of the MFS Globenet/Worldcom Network Fiber Optic Cable Project on Commercial Fisheries off Morro Bay, California
<LI>Expert Witness Testimony in Cable Burial Problem Legal Case
<LI>Flag-1 Fishery Impact Analyses
<LI>Flag-1 Desktop Study
<LI>Fisheries Desktop Study for Neptune Research Cable System
<LI>Fisheries in the Vicinity of the Sicilian Channel
<LI>Fisheries in the Vicinity of Tanner and Cortez Banks, Southern California
<LI>Fisheries off Tsushima Is., Japan
<LI>Fisheries of Bo Hai Gulf, China
<LI>Fisheries Occurring in the Strait of Hormuz
<LI>Fisheries of the South China Sea:  A Review of Available Data
<LI>Fishery Impacts along the TGN Cable System
<LI>Fishery Threats along the Proposed Northstar Cable Route
<LI>Fishery Threats to Cables off Chennai, India
<LI>GIS Files East Coast Korea
<LI>Global West Pre-Lay Grapple Run Vessels Support Service
<LI>Hibernia Cable Route Fishery Impacts
<LI>Initial Feasibility Study for the Neptune Research Cable Project
<LI>Lake Washington CP Cable Crossing Feasibility Study
<LI>Locate Local Japanese Fisheries Expert for Cable Landing Access Negotiations
<LI>Logistical Support Services for the Near Shore Installation of Japan-US Cable System
<LI>Major Bottom Contact Fisheries Along the Proposed Atlantic 1 Cable Route from Fortaleza, Brazil to Tuckerton, New Jersey, U.S.A.
<LI>Major Bottom Contact Fisheries along the Proposed Hibernia Cable Route
<LI>Major Bottom Contact Fisheries along the Proposed TAT-14 Cable Route
<LI>Major Bottom Contact Fisheries along the Proposed SAM-1 Cable Route - Phase 1
<LI>Major Bottom Contact Fisheries along the Proposed Southern Cross Cable Route
<LI>Major Bottom Contact Fisheries along the SAT-3 Cable Route off West Africa
<LI>Major Bottom Contact Fisheries off Monterey, California, Tillamook, Oregon and Cape Flattery to Whidbey Island Washington
<LI>Major Commercial and Sport Fisheries off Morro Bay, California
<LI>Major Fisheries along a Proposed Alaska Cable Route
<LI>Major Fisheries along the Proposed Yellow Sea Cable Route
<LI>Mediterranean Cable Permit Acquisition
<LI>Memo on Stow Nets in Korea Strait
<LI>Monterey Bay Landing Site Development Project
<LI>Monterey Bay Phase III EIS/EIR for Southern Cross Cable System
<LI>Morro Bay Cable Installation Owner Representative Services
<LI>Morro Bay Cable Installation Logistics
<LI>Naval & Maritime Services Trawl Test
<LI>Permit Compliance Monitoring for a Commercial Cable Installation in California
<LI>Permit Condition Monitoring for Global West Cable System
<LI>OPEVAL Site Assessment Study
<LI>Potential Fishery Impacts Along a Proposed Cable Route from Shirley Beach, New York to Hollywood, Florida and Off the North Coast of Cuba and Hispaniola
<LI>Progress & Final Reports: Oregon Bottom Contact Fisheries
<LI>Provide Advice on Design of Cable Repair Ship
<LI>Project 1:  South Korean Bottom Contact Fisheries
<LI>Project 2:  Eastern Mediterranean Bottom Contact Fisheries
<LI>Project 3:  Bottom Contact Fisheries of the Persian Gulf, Gulf of Oman and the Western Arabian Sea
<LI>Provide Fishing Industry Bathymetric and Bottom Composition Data for Global West Cable System California Cable Installations
<LI>Provide Guard Boat Service during Cable Installation
<LI>Provide Guard Boat Services for Global West Cable System California Cable Installations
<LI>Puget Sound Cable Trawl Impact Test
<LI>Review of Fisheries off the Washington and Oregon Coasts
<LI>Risk Assessment of Fishery Impacts on a Submerged Cable Array in the Persian Gulf
<LI>Site Landing and Facilities Analyses
<LI>South Puget Sound Cable Crossing Feasibility Study
<LI>Status of Fisheries and Fishery Resources in the Mediterranean
<LI>Strategic Assessment of Fishery Impacts on Submerged Cable Arrays in the Vicinity of the Sicilian Channel
<LI>Strategic Assessment of Taiwanese Fisheries
<LI>Trawl Beach Test Report
<LI>Unrepeated Submarine Cable Market Evaluation
<LI>Update Report:  Bottom Contact Fisheries of the Persian Gulf, Gulf of Oman and the Western Arabian Sea
<LI>Update Report:  Bottom Contact Fisheries of the Yellow Sea
<LI>WCI Phase I Feasibility Study
<LI>Whidbey Island Cable Crossing Feasibility Study
<LI>Worldwide Survey of Deepwater Trawl Fisheries
</UL>

<A HREF="cable.php" CLASS=tm><b>Back to main Cable-Fisheries Interaction page</b></A>

<BR>
</TD></TR>
</TABLE>
</DIV>
<BR><BR><BR>
</BODY>
</HTML>
