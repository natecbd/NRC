<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<HTML><HEAD><TITLE>Natural Resources Consultants, (NRC)</TITLE>
<meta name="robots" content="index,follow" />
<meta name="googlebot" content="index,follow" />
<meta name="revisit-after" content="10 days" />
<meta name="copyright" content="NRC Corp" />
<meta name="classification" content="Marine and inland fisheries" />
<meta name="author" content="NRC Corp, Seattle, WA" />
<meta name="language" content="EN" />
<META name="description" content="Comprehensive consulting services for all aspects of local, national and international marine and inland fisheries and their related resource base.">
<META name="keywords" content="fisheries, fishing, salmon, groundfish, cable interaction, environmental impact, Endangered, management, conservation"> 

<SCRIPT type="text/javascript" src="mainmenu.js"></SCRIPT>
<script type="text/javascript" src="bsn.Crossfader.js"></script>
<script type="text/javascript" src="bsn.Crossfader_text.js"></script>
<LINK REL=STYLESHEET TYPE="text/css" HREF="styles.css">
</HEAD>
<BODY BGCOLOR="#FFFFFF"  BACKGROUND="pics/bg2.png" TOPMARGIN="0" LEFTMARGIN="0" MARGINHEIGHT="0" MARGINWIDTH="0">
<!-- MENU PAGE POINTER -->

<DIV ALIGN=center>
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" style="text-align:left; width:1000px;">
<TR><TD ALIGN=left style="text-align:left; width:232px;">
<img style="border-width: 0px;" src="pics/logo.png" width="231" height="65" /></TD>
<TD VALIGN=top ALIGN=left style="text-align:left; width:400px;">
<img style="border-width: 0px;" src="pics/spacer.gif" width="400" height="1" /><BR>

<!--TOP MENU-->
<A HREF=company.php CLASS=m3h>COMPANY</A> &nbsp;  &nbsp;     
<A HREF=services.php CLASS=m3h>SERVICES</A> &nbsp;  &nbsp;     
<A HREF=clients.php CLASS=m3h>CLIENTS</A> &nbsp;  &nbsp;     
<A HREF=projects.php CLASS=m3h>PROJECTS</A> &nbsp;  &nbsp;     
<A HREF=staff.php CLASS=m3h>STAFF</A><BR>     
<A HREF=news.php CLASS=m3h>NEWS & EVENTS</A> &nbsp;  &nbsp;        
<A HREF=library.php CLASS=m3h>LIBRARY</A> &nbsp;  &nbsp;       
<A HREF=jobs.php CLASS=m3h>JOBS</A> &nbsp;  &nbsp;      
<A HREF=contact.php CLASS=m3h>CONTACT</A> &nbsp;  &nbsp;   
<A HREF=index.php CLASS=m3h>HOME</A>  

</TD>
<TD ALIGN=left style="text-align:left; width:233px;">
<img style="border-width: 0px;" src="pics/global_leader.png" width="233" height="58" />
</TD><TR>
<TR><TD COLSPAN=2 VALIGN=top><img style="border-width: 0px;" src="pics/top_tag.png" width="436" height="30" /></TD><TD CLASS=cream10 VALIGN=bottom ALIGN=center>SERVICES</TD><TR>
</TABLE>



<!--START MAIN BODY-->
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH="964px" style="text-align:left;">
<TR><TD VALIGN=top>

<!--LEFT MENU-->
<TABLE CELLPADDING="0" CELLSPACING="0" WIDTH="280px" BORDER="0" BGCOLOR=#0c3159>
<TR><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40" HEIGHT="12px" BORDER="0" ALT=""></TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="200" HEIGHT="32px" BORDER="0" ALT=""><BR>
<SPAN CLASS=cream10>Services:</SPAN>
<BR><BR>
<A HREF=fisheries.php CLASS=mm>Fishery Management & Policy</A><BR><A HREF=environ.php CLASS=mm>Environmental Impact</A><BR><A HREF=economic.php CLASS=mm>Economic Assessment & Impacts</A><BR><A HREF=witness.php CLASS=mm>Fishery Expert Witness</A><BR><A HREF=investigation.php CLASS=mm>Salmon Investigations</A><BR><A HREF=infrastructure.php CLASS=mm>Infrastructure Development</A><BR><A HREF=gear.php CLASS=mm>Derelict Gear Removal</A><BR><A HREF=cable.php CLASS=mm>Cable-Fisheries Interaction</A><BR>
<A HREF=energy.php CLASS=mm>Energy Management Program</A><BR> 
</TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40" HEIGHT="282px" BORDER="0" ALT="">
</TD><TR>
</TABLE>

</TD><TD VALIGN=top ALIGN=left WIDTH="684px">
<IMG SRC="pics/spacer.gif" WIDTH="600" HEIGHT="12px" BORDER="0" ALT="" /><BR>
<img src="pics/services_investigation.jpg" width="684px" height="269px"BORDER="0" ALT="" />
</TD>

</TD></TR>
</TABLE>

<TABLE CELLPADDING="0" BACKGROUND="" CELLSPACING="0" BORDER="0" WIDTH=864>
<TR><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="28" HEIGHT="1px" BORDER="0" ALT="">
</TD><TD VALIGN=top CLASS=bodyblue10 style="text-align:left;">
<IMG SRC="pics/spacer.gif" WIDTH="680" HEIGHT="1px" BORDER="0" ALT=""><BR>
<BR>
<b>Salmon Investigations</b>
<BR><BR>
NRC offers well recognized experience to the tremendous variety of issues surrounding salmon and their survival. NRC's salmon experience draws from a deep understanding of not only salmon biology but of commercial and recreational salmon fisheries around the world. NRC has conducted studies of salmon in California, Oregon, the Columbia River Basin, Washington, British Columbia, Alaska and Russia. General areas of expertise include: 
<UL>
<LI>salmon life history, ecology and behavior
<LI>harvest management to ensure sustainability
<LI>salmon conservation
<LI>hatchery/wild salmon interactions
<LI>salmon run size and run timing forecasting 
<LI>ocean ecology of salmon
<LI>limnology 
<LI>water quality
</UL>

Specific NRC salmon research conducted for a variety of clients covers a broad set of professional services including:
<UL>
<LI>analyses of salmon productivity and carrying capacity 
<LI>assessments of salmon interception/bycatch fisheries 
<LI>effects of salmon hatcheries on wild stocks 
<LI>scale growth and age analyses
<LI>predator/prey interactions 
<LI>fish passage analyses
<LI>assessments of habitat quality and habitat restoration
<LI>run reconstruction 
<LI>catch and release survival
<LI>pile driving noise impacts
<LI>oil spill effects on salmonids 
<LI>expert review panels
</UL>


Over the past 30+ years, NRC scientists have published many significant project reports for public and private clients alike and have authored or co-authored numerous peer reviewed technical documents on Pacific salmon.
<BR>
</TD></TR>
</TABLE>
</DIV>
<BR><BR><BR>
</BODY>
</HTML>
