<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<HTML><HEAD><TITLE>Natural Resources Consultants, (NRC)</TITLE>
<meta name="robots" content="index,follow" />
<meta name="googlebot" content="index,follow" />
<meta name="revisit-after" content="10 days" />
<meta name="copyright" content="NRC Corp" />
<meta name="classification" content="Marine and inland fisheries" />
<meta name="author" content="NRC Corp, Seattle, WA" />
<meta name="language" content="EN" />
<META name="description" content="Comprehensive consulting services for all aspects of local, national and international marine and inland fisheries and their related resource base.">
<META name="keywords" content="fisheries, fishing, salmon, groundfish, cable interaction, environmental impact, Endangered, management, conservation"> 

<SCRIPT type="text/javascript" src="mainmenu.js"></SCRIPT>
<script type="text/javascript" src="bsn.Crossfader.js"></script>
<script type="text/javascript" src="bsn.Crossfader_text.js"></script>
<LINK REL=STYLESHEET TYPE="text/css" HREF="styles.css">
</HEAD>
<BODY BGCOLOR="#FFFFFF"  BACKGROUND="pics/bg2.png" TOPMARGIN="0" LEFTMARGIN="0" MARGINHEIGHT="0" MARGINWIDTH="0">
<!-- MENU PAGE POINTER -->

<DIV ALIGN=center>
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" style="text-align:left; width:1000px;">
<TR><TD ALIGN=left style="text-align:left; width:232px;">
<img style="border-width: 0px;" src="pics/logo.png" width="231" height="65" /></TD>
<TD VALIGN=top ALIGN=left style="text-align:left; width:400px;">
<img style="border-width: 0px;" src="pics/spacer.gif" width="400" height="1" /><BR>

<!--TOP MENU-->
<A HREF=company.php CLASS=m3h>COMPANY</A> &nbsp;  &nbsp;     
<A HREF=services.php CLASS=m3h>SERVICES</A> &nbsp;  &nbsp;     
<A HREF=clients.php CLASS=m3h>CLIENTS</A> &nbsp;  &nbsp;     
<A HREF=projects.php CLASS=m3h>PROJECTS</A> &nbsp;  &nbsp;     
<A HREF=staff.php CLASS=m3h>STAFF</A><BR>     
<A HREF=news.php CLASS=m3h>NEWS & EVENTS</A> &nbsp;  &nbsp;        
<A HREF=library.php CLASS=m3h>LIBRARY</A> &nbsp;  &nbsp;       
<A HREF=jobs.php CLASS=m3h>JOBS</A> &nbsp;  &nbsp;      
<A HREF=contact.php CLASS=m3h>CONTACT</A> &nbsp;  &nbsp;   
<A HREF=index.php CLASS=m3h>HOME</A>  

</TD>
<TD ALIGN=left style="text-align:left; width:233px;">
<img style="border-width: 0px;" src="pics/global_leader.png" width="233" height="58" />
</TD><TR>
<TR><TD COLSPAN=2 VALIGN=top><img style="border-width: 0px;" src="pics/top_tag.png" width="436" height="30" /></TD><TD CLASS=cream10 VALIGN=bottom ALIGN=center>CLIENTS</TD><TR>
</TABLE>



<!--START MAIN BODY-->
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH="964px" style="text-align:left;">
<TR><TD VALIGN=top>

<!--LEFT MENU-->
<TABLE CELLPADDING="0" CELLSPACING="0" WIDTH="280px" BORDER="0" BGCOLOR=#0c3159>
<TR><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40" HEIGHT="12px" BORDER="0" ALT=""></TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="200" HEIGHT="32px" BORDER="0" ALT=""><BR>
<SPAN CLASS=cream10>Services:</SPAN>
<BR><BR>
<A HREF=fisheries.php CLASS=mm>Fishery Management & Policy</A><BR><A HREF=environ.php CLASS=mm>Environmental Impact</A><BR><A HREF=economic.php CLASS=mm>Economic Assessment & Impacts</A><BR><A HREF=witness.php CLASS=mm>Fishery Expert Witness</A><BR><A HREF=investigation.php CLASS=mm>Salmon Investigations</A><BR><A HREF=infrastructure.php CLASS=mm>Infrastructure Development</A><BR><A HREF=gear.php CLASS=mm>Derelict Gear Removal</A><BR><A HREF=cable.php CLASS=mm>Cable-Fisheries Interaction</A><BR>
<A HREF=energy.php CLASS=mm>Energy Management Program</A><BR> 
</TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40" HEIGHT="282px" BORDER="0" ALT="">
</TD><TR>
</TABLE>

</TD><TD VALIGN=top ALIGN=left WIDTH="684px">
<IMG SRC="pics/spacer.gif" WIDTH="600" HEIGHT="12px" BORDER="0" ALT="" /><BR>
<img src="pics/clients.jpg" width="684px" height="269px"BORDER="0" ALT="" />
</TD>

</TD></TR>
</TABLE>

<TABLE CELLPADDING="0" BACKGROUND="" CELLSPACING="0" BORDER="0" WIDTH=964>
<TR><TD VALIGN=top CLASS=gray10><IMG SRC="pics/spacer.gif" WIDTH="280" HEIGHT="28px" BORDER="0" ALT=""><BR>

<A HREF="clients_counties.php" CLASS=tm>Counties, Boroughs, Cities and Ports</A><BR>
<A HREF="clients_government.php" CLASS=tm>State and Federal Government Agencies</A><BR>
<A HREF="clients_nonprofit.php" CLASS=tm>Nonprofit, Native and Tribal Entities</A><BR>
<A HREF="clients_private.php" CLASS=tm>Private Sector Firms</A><BR>
<A HREF="clients_legal.php" CLASS=tm>Legal Clients</A><BR>
<A HREF="clients_international.php" CLASS=tm>International Clients</A><BR>


</TD><TD VALIGN=top CLASS=bodyblue10>
<IMG SRC="pics/spacer.gif" WIDTH="580" HEIGHT="22px" BORDER="0" ALT=""><BR>
<b>CLIENTS :: Legal Clients</b>
<BR><BR>
Bauer, Moynihan and Johnson<BR>
Blaker, Monk and Elliston<BR>
Bliss Riordan<BR>
Bogle and Gates<BR>
Chalos and Brown<BR>
Cohen, Milstein and Hausfield<BR>
Danielson, Harrigan and Tollefson<BR>
Faegre and Benson, LLP<BR>
Gordon, Thomas, Honeywell, Malanca, Peterson & Daheim, P.L.L.C.
<BR><BR>
Click category at left for another list.



</UL>

<BR>
</TD></TR>
</TABLE>
</DIV>
<BR><BR><BR>
</BODY>
</HTML>
