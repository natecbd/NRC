<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<HTML><HEAD><TITLE>Natural Resources Consultants, (NRC)</TITLE>
<meta name="robots" content="index,follow" />
<meta name="googlebot" content="index,follow" />
<meta name="revisit-after" content="10 days" />
<meta name="copyright" content="NRC Corp" />
<meta name="classification" content="Marine and inland fisheries" />
<meta name="author" content="NRC Corp, Seattle, WA" />
<meta name="language" content="EN" />
<META name="description" content="Comprehensive consulting services for all aspects of local, national and international marine and inland fisheries and their related resource base.">
<META name="keywords" content="fisheries, fishing, salmon, groundfish, cable interaction, environmental impact, Endangered, management, conservation"> 

<SCRIPT type="text/javascript" src="mainmenu.js"></SCRIPT>
<script type="text/javascript" src="bsn.Crossfader.js"></script>
<script type="text/javascript" src="bsn.Crossfader_text.js"></script>
<LINK REL=STYLESHEET TYPE="text/css" HREF="styles.css">
</HEAD>
<BODY BGCOLOR="#FFFFFF"  BACKGROUND="pics/bg2.png" TOPMARGIN="0" LEFTMARGIN="0" MARGINHEIGHT="0" MARGINWIDTH="0">
<!-- MENU PAGE POINTER -->

<DIV ALIGN=center>
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" style="text-align:left; width:1000px;">
<TR><TD ALIGN=left style="text-align:left; width:232px;">
<A HREF="index.php"><img style="border-width: 0px;" src="pics/logo.png" width="231" height="65" /></A></TD>
<TD VALIGN=top ALIGN=left style="text-align:left; width:400px;">
<img style="border-width: 0px;" src="pics/spacer.gif" width="400" height="1" /><BR>

<!--TOP MENU-->
<A HREF=company.php CLASS=m3h>COMPANY</A> &nbsp;  &nbsp;     
<A HREF=services.php CLASS=m3h>SERVICES</A> &nbsp;  &nbsp;     
<A HREF=clients.php CLASS=m3h>CLIENTS</A> &nbsp;  &nbsp;     
<A HREF=projects.php CLASS=m3h>PROJECTS</A> &nbsp;  &nbsp;     
<A HREF=staff.php CLASS=m3h>STAFF</A><BR>     
<A HREF=news.php CLASS=m3h>NEWS & EVENTS</A> &nbsp;  &nbsp;        
<A HREF=library.php CLASS=m3h>LIBRARY</A> &nbsp;  &nbsp;       
<A HREF=jobs.php CLASS=m3h>JOBS</A> &nbsp;  &nbsp;      
<A HREF=contact.php CLASS=m3h>CONTACT</A> &nbsp;  &nbsp;   
<A HREF=index.php CLASS=m3h>HOME</A>  

</TD>
<TD ALIGN=left style="text-align:left; width:233px;">
<img style="border-width: 0px;" src="pics/global_leader.png" width="233" height="58" />
</TD><TR>
<TR><TD COLSPAN=2 VALIGN=top><img style="border-width: 0px;" src="pics/top_tag.png" width="436" height="30" /></TD><TD CLASS=cream10 VALIGN=bottom ALIGN=center>STAFF</TD><TR>
</TABLE>



<!--START MAIN BODY-->
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH="964px" style="text-align:left;">
<TR><TD VALIGN=top>

<!--LEFT MENU-->
<TABLE CELLPADDING="0" CELLSPACING="0" WIDTH="280px" BORDER="0" BGCOLOR=#0c3159>
<TR><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40" HEIGHT="12px" BORDER="0" ALT=""></TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="200" HEIGHT="32px" BORDER="0" ALT=""><BR>
<SPAN CLASS=cream10>Services:</SPAN>
<BR><BR>
<A HREF=fisheries.php CLASS=mm>Fishery Management & Policy</A><BR><A HREF=environ.php CLASS=mm>Environmental Impact</A><BR><A HREF=economic.php CLASS=mm>Economic Assessment & Impacts</A><BR><A HREF=witness.php CLASS=mm>Fishery Expert Witness</A><BR><A HREF=investigation.php CLASS=mm>Salmon Investigations</A><BR><A HREF=infrastructure.php CLASS=mm>Infrastructure Development</A><BR><A HREF=gear.php CLASS=mm>Derelict Gear Removal</A><BR><A HREF=cable.php CLASS=mm>Cable-Fisheries Interaction</A><BR>
<A HREF=energy.php CLASS=mm>Energy Management Program</A><BR> 
</TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40" HEIGHT="282px" BORDER="0" ALT="">
</TD><TR>
</TABLE>

</TD><TD VALIGN=top ALIGN=left WIDTH="684px">
<IMG SRC="pics/spacer.gif" WIDTH="600" HEIGHT="12px" BORDER="0" ALT="" /><BR>
<img src="pics/staff_alverson.jpg" width="684px" height="269px"BORDER="0" ALT="" />
</TD>

</TD></TR>
</TABLE>

<TABLE CELLPADDING="0" BACKGROUND="" CELLSPACING="0" BORDER="0" WIDTH=964>
<TR><TD VALIGN=top CLASS=gray10><IMG SRC="pics/spacer.gif" WIDTH="280" HEIGHT="1px" BORDER="0" ALT="">
<BR>
Active Staff<BR>(click name for more information)<BR><BR>
<A HREF="staff_steven.php" CLASS=tm>Steven E. Hughes</A>  <BR>  
<A HREF="staff_gregory.php" CLASS=tm>Gregory T. Ruggerone</A>  <BR>  
<A HREF="staff_goodman.php" CLASS=tm>Scott Goodman</A>  <BR>
<A HREF="staff_kyle.php" CLASS=tm>Kyle L. Antonelis</A>  <BR> 
<BR>       
<A HREF="staff_jeffrey.php" CLASS=tm>Jeffrey A. June</A>  (retired)<BR> 

</TD><TD VALIGN=top CLASS=bodyblue10>
<BR>

<!--***<BR> 
<A HREF="staff_alverson.htm" CLASS=tm>Dayton L. Alverson </A>  (deceased)<BR>  -->                 
      
    
</DIV> 
<BR>
<IMG SRC="../pics/spacer.gif" WIDTH=221 HEIGHT=22 BORDER=0 ALT="">
<BR>
<DIV CLASS=body-blue10>
(Originally published January 23, 2013 at 8:00 PM)<BR>
<b>Obituary: Dayton Lee Alverson, marine biologist, dies at 88</b>
<BR><BR>
Lee Alverson was a trailblazing biologist who helped explore and protect North Pacific fisheries.<BR>
By Hal Bernton -- Seattle Times reporter
<BR><BR>
Shortly after the 1989 Exxon Valdez oil spill in Alaska, a company representative called marine biologist Lee Alverson and proposed to hire his consulting firm to help assess damage in the aftermath of a disaster that dumped some 11 million gallons of crude into Prince William Sound.
<BR>
It was a lucrative offer that likely could result in multimillion-dollar billing fees.
<BR>
He turned it down
<BR>
“That’s one thing that showed me the integrity of my father,” recalls his daughter, Susan Alverson Wilson. “He said he loved the fishermen and wanted to represent them.”
<BR>
Dayton Lee Alverson, a longtime resident of Normandy Park, died Saturday at the age of 88, deep into a remarkable career as a trailblazing scientist who helped explore, launch and protect the North Pacific fisheries pursued by Seattle-based fleets.
<BR>
Dr. Alverson was born Oct. 7, 1924, in San Diego, Calif., and grew up in a Navy family that followed his father on a series of assignments that included a year on Tatoosh Island in Washington, and several years in Hilo, Hawaii. There, Dr. Alverson, in what he later described as one of the best times of his life, paddled a small outrigger canoe in search of parrot fish, puffers and other sea life.
<BR>
Dr. Alverson also joined the Navy, and, in 1944 he deployed behind enemy lines in China as a radio operator.
<BR>
He moved to Seattle in 1947 to study fisheries at the University of Washington, and he later became an affiliate professor with the School of Marine and Environmental Affairs.
<BR>
As a federal biologist based in Seattle, Dr. Alverson published research intended to alert the U.S. fishing industry to vast potential seafood harvests. But as he headed off to international fishing conferences, he realized that his writing also had helped draw a surge of Soviet and Asian factory fleets to fish off U.S. coasts.
<BR>
“That didn’t make me feel very good, and I quickly realized that we didn’t have any management and we didn't have any control,” Dr. Alverson said in a 2008 interview with The Seattle Times.
<BR>
In the mid-1970s, Dr. Alverson emerged as an outspoken proponent of extending the U.S. fishing boundaries to 200 miles, an idea that rankled some State Department officials who feared the diplomatic repercussions.
<BR>
But Dr. Alverson, who served as director of what was then the Northwest and Alaska Fishery Science Center, didn’t back down. He worked closely with Sen. Warren Magnuson, D-Wash., and Sen. Ted Stevens, R-Alaska, to pass the landmark 1976 federal fishery law that created a 200-mile zone and began a new era of managing U.S. seafood resources.
<BR>
“I was in and out of those Senate offices for almost two years, and I can’t count the number of times I saw Lee Alverson,” said Tom Casey, a Seattle fishery consultant.
<BR>
In 1980, after leaving the federal fishery service, Dr. Alverson co-founded Natural Resources Consultants. He helped in a successful lobbying effort to obtain federal loan guarantees that were a key to financing a new generation of U.S. factory trawlers that took over from foreign fleets.
<BR>
“He is somewhat responsible for the billion-dollar seafood industry we have in Washington and Alaska these days,” said Jeffrey June, a partner at Natural Resources Consultants.
<BR>
Over the years, the firm’s client list expanded to include the military, the World Bank, environmental groups and communication companies.
<BR>
Dr. Alverson published more than 150 papers and in 2008 produced an autobiography, “Race to The Sea.” In recent years, though slowed by a stroke, he continued to tackle fishery issues. At the time of his death, he was working on an article titled “Exploitation of Ocean Living Resources in the 20th Century.”
<BR>
“His mind was sharp as a tack. It’s just his body that gave out on him,” June said.
<BR>
Dr. Alverson is survived by his wife of 67 years, Ruby Alverson; his daughter, Susan Alverson Wilson, of Federal Way; and son, Robert Alverson, of Bothell.
<BR>
He is also survived by four grandchildren and two great-grandchildren.
<BR>

</TD></TR>
</TABLE>
</DIV>
<BR><BR><BR>
</BODY>
</HTML>
