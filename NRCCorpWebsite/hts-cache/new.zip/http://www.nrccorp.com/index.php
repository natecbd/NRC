<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<HTML><HEAD><TITLE>Natural Resources Consultants, (NRC)</TITLE>
<meta name="robots" content="index,follow" />
<meta name="googlebot" content="index,follow" />
<meta name="revisit-after" content="10 days" />
<meta name="copyright" content="NRC Corp" />
<meta name="classification" content="Marine and inland fisheries" />
<meta name="author" content="NRC Corp, Seattle, WA" />
<meta name="language" content="EN" />
<META name="description" content="Comprehensive consulting services for all aspects of local, national and international marine and inland fisheries and their related resource base.">
<META name="keywords" content="fisheries, fishing, salmon, groundfish, cable interaction, environmental impact, Endangered, management, conservation">  

<SCRIPT type="text/javascript" src="mainmenu.js"></SCRIPT>
<script type="text/javascript" src="bsn.Crossfader.js"></script>
<script type="text/javascript" src="bsn.Crossfader_text.js"></script>
<LINK REL=STYLESHEET TYPE="text/css" HREF="styles.css">
</HEAD>
<BODY BGCOLOR="#FFFFFF"  BACKGROUND="pics/bg1.png" TOPMARGIN="0" LEFTMARGIN="0" MARGINHEIGHT="0" MARGINWIDTH="0">


<DIV ALIGN=center>
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" style="text-align:left; width:1000px;">
<TR><TD ALIGN=left style="text-align:left; width:232px;">
<img style="border-width: 0px;" src="pics/logo.png" width="231" height="65" /></TD>
<TD VALIGN=top ALIGN=left style="text-align:left; width:400px;">
<img style="border-width: 0px;" src="pics/spacer.gif" width="400" height="1" /><BR>

<!--TOP MENU-->
<A HREF=company.php CLASS=m3h>COMPANY</A> &nbsp;  &nbsp;     
<A HREF=services.php CLASS=m3h>SERVICES</A> &nbsp;  &nbsp;     
<A HREF=clients.php CLASS=m3h>CLIENTS</A> &nbsp;  &nbsp;     
<A HREF=projects.php CLASS=m3h>PROJECTS</A> &nbsp;  &nbsp;     
<A HREF=staff.php CLASS=m3h>STAFF</A><BR>     
<A HREF=news.php CLASS=m3h>NEWS & EVENTS</A> &nbsp;  &nbsp;        
<A HREF=library.php CLASS=m3h>LIBRARY</A> &nbsp;  &nbsp;       
<A HREF=jobs.php CLASS=m3h>JOBS</A> &nbsp;  &nbsp;      
<A HREF=contact.php CLASS=m3h>CONTACT</A> &nbsp;  &nbsp;   
<A HREF=index.php CLASS=m3h>HOME</A>  

</TD>
<TD ALIGN=left style="text-align:left; width:233px;">
<img style="border-width: 0px;" src="pics/global_leader.png" width="233" height="58" />
</TD><TR>
<TR><TD COLSPAN=3 CLASS=cream9 VALIGN=top><img style="border-width: 0px;" src="pics/top_tag.png" width="436" height="30" />Producing factual information on living resources and the consequences of human use.</TD><TR>
</TABLE>

<!--Producing factual information on living resources and the consequendes of human use.-->


<!--START MAIN BODY-->
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH="900px" style="text-align:left;">
<TR><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="200" HEIGHT="12px" BORDER="0" ALT=""><BR>

<!--LEFT MENU-->
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH=200px style="text-align:left;">
<TR><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="200" HEIGHT="1px" BORDER="0" ALT="">


<SPAN CLASS=cream10>Services:</SPAN>
<BR><BR>
<A HREF=fisheries.php CLASS=mm>Fishery Management & Policy</A><BR><A HREF=environ.php CLASS=mm>Environmental Impact</A><BR><A HREF=economic.php CLASS=mm>Economic Assessment & Impacts</A><BR><A HREF=witness.php CLASS=mm>Fishery Expert Witness</A><BR><A HREF=investigation.php CLASS=mm>Salmon Investigations</A><BR><A HREF=infrastructure.php CLASS=mm>Infrastructure Development</A><BR><A HREF=gear.php CLASS=mm>Derelict Gear Removal</A><BR><A HREF=cable.php CLASS=mm>Cable-Fisheries Interaction</A><BR>
<A HREF=energy.php CLASS=mm>Energy Management Program</A><BR> 

</TD></TR>
</TABLE>

<IMG SRC="pics/spacer.gif" WIDTH="200" HEIGHT="60px" BORDER="0" ALT=""><BR>
<!--LEFT NEWS-->
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH=200px style="text-align:left;">
<TR><TD VALIGN=top CLASS=cream9><IMG SRC="pics/spacer.gif" WIDTH="200" HEIGHT="1px" BORDER="0" ALT="">
<b>IN THE NEWS</b><BR>
Too many pink salmon could be creating ecosystem consequences. <BR><A href=http://news.nationalgeographic.com/news/2014/03/140331-salmon-seabirds-pacific-fish-animals-science/ CLASS=mm TARGET=_blank>[Read More]</A>

</TD><TR>
</TABLE>




</TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40px" HEIGHT="1px" BORDER="0" ALT=""></TD>
<TD VALIGN=top >
<IMG SRC="pics/spacer.gif" WIDTH="700" HEIGHT="1px" BORDER="0" ALT="">
<BR>
<div ID="photo" z-index:2;" STYLE="position:relative; top:0px; width:689px; ">      	
		<div id="cf1"><img src="pics/home_rotate/1.jpg" /></div>
		<div id="cf2"><img src="pics/home_rotate/2.jpg" /></div>
		<div id="cf3"><img src="pics/home_rotate/3.jpg" /></div>
        <div id="cf4"><img src="pics/home_rotate/4.jpg" /></div>
		<div id="cf5"><img src="pics/home_rotate/5.jpg" /></div>
		<div id="cf6"><img src="pics/home_rotate/6.jpg" /></div>
</DIV>
<div class="iepngbugfix" id="headermask"></div>
<script type="text/javascript">
var cf = new Crossfader( new Array('cf1','cf2','cf3','cf4','cf5','cf6'), 1000, 4000 );
</script>
<img style="border-width: 0px;" src="pics/home_rotate/1.jpg" width="689" height="464" />
</TD></TR>

<TR><TD VALIGN=top COLSPAN=2>
<!--<img style="border-width: 0px;" src="pics/blue_water.png" width="240" height="200" />-->

<TABLE>
<TR><TD VALIGN=top CLASS=gray10><IMG SRC="pics/spacer.gif" WIDTH="200" HEIGHT="1px" BORDER="0" ALT="">
Natural Resources Consultants, Inc.
<BR><BR>
4039 21st Avenue West, Suite 404<BR>
Seattle, WA 98199 USA<BR>
ph: 206.285.3480<BR>
fx: 206.283.8263<BR>
eMail: nrc@nrccorp.com
</SPAN><BR>
<IMG SRC="pics/spacer.gif" WIDTH="40px" HEIGHT="24px" BORDER="0" ALT="">
</TD><TR>
</TABLE>



</TD>
<TD VALIGN=top ALIGN=center>
<!--BODY TEXT-->
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH=600px style="text-align:left;">
<TR><TD VALIGN=top CLASS=bodyblue10><IMG SRC="pics/spacer.gif" WIDTH="600" HEIGHT="1px" BORDER="0" ALT="">
<BR><BR>
Since 1980, <b>Natural Resources Consultants</b> has been a global leader in marine resource and environmental consulting. Our principals draw from unique hands on experience and science based knowledge, providing our clients with timely, well informed, independent advice. 
</TD></TR>
</TABLE>

<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH=600px style="text-align:left;">
<TR><TD VALIGN=top ALIGN=center><IMG SRC="pics/spacer.gif" WIDTH="600" HEIGHT="1px" BORDER="0" ALT=""><BR>

<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH=500px style="text-align:left;">
<TR><TD  CLASS=bodyblue10>
 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .   <BR>
<b>What Our Clients Say...</b><BR>
<i>"Our Derelict Fishing Gear Program is recognized as a national model as a science-based solution to the pervasive problem of lost and abandoned fishing gear in our marine waters. Natural Resources Consultants helped us develop the program from the start and continues to work hand in hand with us to manage the vessels, data collection, and outreach and also to strategize progressive approaches to the problem. We rely on their fisheries expertise, their ability to work with fishermen and resource managers alike, and their consistent integrity."</i>
<BR> <IMG SRC="pics/spacer.gif" WIDTH="40px" HEIGHT="1px" BORDER="0" ALT=""> Joan Drinkwin
<BR> <IMG SRC="pics/spacer.gif" WIDTH="40px" HEIGHT="1px" BORDER="0" ALT=""> Northwest Straits Foundation
</TD></TR>
</TABLE>
<IMG SRC="pics/spacer.gif" WIDTH="600" HEIGHT="24px" BORDER="0" ALT=""><BR>
<SPAN CLASS=bodyblue10>

</TD></TR>
</TABLE>
<!--END MAIN BODY-->



</DIV>

</BODY>
</HTML>
