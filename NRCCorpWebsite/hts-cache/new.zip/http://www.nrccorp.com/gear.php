<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<HTML><HEAD><TITLE>Natural Resources Consultants, (NRC)</TITLE>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta name="robots" content="index,follow" />
<meta name="googlebot" content="index,follow" />
<meta name="revisit-after" content="10 days" />
<meta name="copyright" content="NRC Corp" />
<meta name="classification" content="Marine and inland fisheries" />
<meta name="author" content="NRC Corp, Seattle, WA" />
<meta name="language" content="EN" />
<META name="description" content="Comprehensive consulting services for all aspects of local, national and international marine and inland fisheries and their related resource base.">
<META name="keywords" content="fisheries, fishing, salmon, groundfish, cable interaction, environmental impact, Endangered, management, conservation"> 

<SCRIPT type="text/javascript" src="mainmenu.js"></SCRIPT>
<script type="text/javascript" src="bsn.Crossfader.js"></script>
<script type="text/javascript" src="bsn.Crossfader_text.js"></script>
<LINK REL=STYLESHEET TYPE="text/css" HREF="styles.css">
</HEAD>
<BODY BGCOLOR="#FFFFFF"  BACKGROUND="pics/bg2.png" TOPMARGIN="0" LEFTMARGIN="0" MARGINHEIGHT="0" MARGINWIDTH="0">
<!-- MENU PAGE POINTER -->

<DIV ALIGN=center>
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" style="text-align:left; width:1000px;">
<TR><TD ALIGN=left style="text-align:left; width:232px;">
<img style="border-width: 0px;" src="pics/logo.png" width="231" height="65" /></TD>
<TD VALIGN=top ALIGN=left style="text-align:left; width:400px;">
<img style="border-width: 0px;" src="pics/spacer.gif" width="400" height="1" /><BR>

<!--TOP MENU-->
<A HREF=company.php CLASS=m3h>COMPANY</A> &nbsp;  &nbsp;     
<A HREF=services.php CLASS=m3h>SERVICES</A> &nbsp;  &nbsp;     
<A HREF=clients.php CLASS=m3h>CLIENTS</A> &nbsp;  &nbsp;     
<A HREF=projects.php CLASS=m3h>PROJECTS</A> &nbsp;  &nbsp;     
<A HREF=staff.php CLASS=m3h>STAFF</A><BR>     
<A HREF=news.php CLASS=m3h>NEWS & EVENTS</A> &nbsp;  &nbsp;        
<A HREF=library.php CLASS=m3h>LIBRARY</A> &nbsp;  &nbsp;       
<A HREF=jobs.php CLASS=m3h>JOBS</A> &nbsp;  &nbsp;      
<A HREF=contact.php CLASS=m3h>CONTACT</A> &nbsp;  &nbsp;   
<A HREF=index.php CLASS=m3h>HOME</A>  

</TD>
<TD ALIGN=left style="text-align:left; width:233px;">
<img style="border-width: 0px;" src="pics/global_leader.png" width="233" height="58" />
</TD><TR>
<TR><TD COLSPAN=2 VALIGN=top><img style="border-width: 0px;" src="pics/top_tag.png" width="436" height="30" /></TD><TD CLASS=cream10 VALIGN=bottom ALIGN=center>SERVICES</TD><TR>
</TABLE>



<!--START MAIN BODY-->
<TABLE CELLPADDING="0" CELLSPACING="0" BORDER="0" WIDTH="964px" style="text-align:left;">
<TR><TD VALIGN=top>

<!--LEFT MENU-->
<TABLE CELLPADDING="0" CELLSPACING="0" WIDTH="280px" BORDER="0" BGCOLOR=#0c3159>
<TR><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40" HEIGHT="12px" BORDER="0" ALT=""></TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="200" HEIGHT="32px" BORDER="0" ALT=""><BR>
<SPAN CLASS=cream10>Services:</SPAN>
<BR><BR>
<A HREF=fisheries.php CLASS=mm>Fishery Management & Policy</A><BR><A HREF=environ.php CLASS=mm>Environmental Impact</A><BR><A HREF=economic.php CLASS=mm>Economic Assessment & Impacts</A><BR><A HREF=witness.php CLASS=mm>Fishery Expert Witness</A><BR><A HREF=investigation.php CLASS=mm>Salmon Investigations</A><BR><A HREF=infrastructure.php CLASS=mm>Infrastructure Development</A><BR><A HREF=gear.php CLASS=mm>Derelict Gear Removal</A><BR><A HREF=cable.php CLASS=mm>Cable-Fisheries Interaction</A><BR>
<A HREF=energy.php CLASS=mm>Energy Management Program</A><BR> 
</TD><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="40" HEIGHT="282px" BORDER="0" ALT="">
</TD><TR>
</TABLE>

</TD><TD VALIGN=top ALIGN=left WIDTH="684px">
<IMG SRC="pics/spacer.gif" WIDTH="600" HEIGHT="12px" BORDER="0" ALT="" /><BR>
<img src="pics/services_gear.jpg" width="684px" height="269px"BORDER="0" ALT="" />
</TD>

</TD></TR>
</TABLE>

<TABLE CELLPADDING="0" BACKGROUND="" CELLSPACING="0" BORDER="0" WIDTH=864>
<TR><TD VALIGN=top><IMG SRC="pics/spacer.gif" WIDTH="28" HEIGHT="1px" BORDER="0" ALT="">
</TD><TD VALIGN=top CLASS=bodyblue10 style="text-align:left;">
<IMG SRC="pics/spacer.gif" WIDTH="680" HEIGHT="1px" BORDER="0" ALT=""><BR>
<BR>
<b>Derelict Gear Removal</b>
<BR><BR>
NRC works collaboratively with members of the fishing industry, government agencies (federal, state, tribal, county, etc.) and other organizations to find solutions to derelict fishing gear and related marine resource management issues while understanding the needs of all involved stakeholders.
<BR><BR>
Northwest Straits Foundation Derelict Fishing Gear Program
<BR><BR>
NRC is intimately involved with the Northwest Straits Marine Conservation Initiative’s highly successful and groundbreaking Derelict Fishing Gear Program in Washington State waters. As Derelict Gear Program Field Operations Manager for the Northwest Straits Foundation, the NRC team of field biologists and researchers is responsible for managing and conducting nearly all of the hands-on, on-the-water work of removing derelict gear and are directly responsible for all aspects of data collection including documenting when, where and how much gear of what type is removed and all associated biological information from the gear removals. 
<BR><BR>
In partnership with the Northwest Straits Foundation and Northwest Straits Commission, NRC has undertaken derelict fishing gear pilot demonstration projects in Virginia, North Carolina, California and British Columbia. 
<BR><BR>
NRC has also conducted unique research projects into the impacts of derelict fishing gear including:
<BR>
<UL>
<LI>Long-term species impacts from derelict fishing nets
<LI>Loss rates of fishing nets
<LI>Probability modeling for derelict gillnets in Washington and British Columbia
<LI>Habitat recovery rates after derelict gear removal
<LI>Economic and ecological impacts of derelict crab pots and loss rates of crab pots
<LI>Impacts and loss rates of shrimp pots
<LI>Effectiveness of escapement mechanisms of crab pots
</UL>
<BR>
NRC publishes the findings of pre-removal surveys to locate and quantify derelict fishing gear, final reports of derelict fishing gear removal projects and information on derelict fishing gear impacts and ecosystem recovery. A list of recent publications can be found here: <A HREF=http://www.derelictgear.org/Research.aspx TARGET=_blank>www.derelictgear.org/Research.aspx</A>
<BR><BR>
<b>Other Derelict Fishing Gear Work</b>
<BR><BR>
NRC works with The Nature Conservancy and the Quinault Indian Nation on derelict net removal projects in the lower Chehalis River and Grays Harbor area while also conducting derelict crab pot removals along the Washington State Outer Coast.  This work has included innovation of technical equipment used during removals.
<BR><BR>
Other ongoing projects include annual derelict crab pot surveys and removals in Port Gardner for the Snohomish County Marine Resources Committee.  These yearly operations provide data used to determine yearly pot loss rates in the region, and identifies changes in fisher behavior as it pertains to pot loss and compliance of the legal use of escape cord.  This research assists the Marine Resource Committee in evaluating education programs and identifying next steps in reducing derelict crab pots and the associated impacts in the area.
<BR><BR>
NRC personnel have been invited experts regarding derelict fishing gear on the local, regional, national and international scale while also presenting research at multiple conferences and workshops.  We have previous and continued participation at:
<BR>
<UL>
<LI>United Nations Environment Program Convention on Biological Diversity
<LI>The West Coast Governors Agreement on Ocean Health
<LI>The International Marine Debris Conference
<LI>Salish Sea Ecosystem Conferences
<LI>Puget Sound Rockfish Workgroup
<LI>Pacific Seabird Group Conferences
<LI>American Fisheries Society Conferences
<LI>And many more
</UL>
<BR>
NRC has worked with a variety of federal, state and private entities to provide planning and implementation of locating, removing, and documenting impacts of derelict fishing gear; including: 
<UL>
<LI>Northwest Straits Foundation 
<LI>Northwest Straits Commission
<LI>Marine Resources Committees of Whatcom, Skagit, San Juan, Snohomish, Clallam, Jefferson, and Island counties 
<LI>The Nature Conservancy
<LI>National Oceanic and Atmospheric Administration 
<LI>U.S. Navy 
<LI>Washington Department of Fish and Wildlife 
<LI>Washington Department of Natural Resources 
<LI>Washington Sea Grant Program 
<LI>Puget Sound Water Quality Action Team 
<LI>Quinault Indian Nation, Stillaguamish Tribe and other Washington Tribes 
<LI>Hood Canal Salmon Enhancement Group 
<LI>Commercial fishing and diving companies 
<LI>Private foundations 
</UL>
<BR>
For more information about the Northwest Straits Foundation's derelict fishing gear program visit <A HREF=http://www.nwstraitsfoundation.org/ TARGET=_blank>www.nwstraitsfoundation.org</A> and <A HREF=http://www.derelictgear.org/Research.aspx TARGET=_blank>www.derelictgear.org</A> <BR>
</TD></TR>
</TABLE>
</DIV>
<BR><BR><BR>
</BODY>
</HTML>
